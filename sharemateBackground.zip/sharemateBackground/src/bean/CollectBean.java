package bean;

public class CollectBean {
	private UserBean user;
	private NoteBean note;
	public CollectBean() {
		super();
		// TODO Auto-generated constructor stub
	}
	public UserBean getUser() {
		return user;
	}
	public void setUser(UserBean user) {
		this.user = user;
	}
	public NoteBean getNote() {
		return note;
	}
	public void setNote(NoteBean note) {
		this.note = note;
	}
}
